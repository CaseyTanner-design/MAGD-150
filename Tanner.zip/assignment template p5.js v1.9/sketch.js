function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(30);
  colorMode(RGB, 100)
  frameRate(30)
  
  fill(0, 100, 0)
  textSize(16);
  text(`x: ${mouseX} y: ${mouseY}`, 50, 50);
  line(pmouseX, pmouseY, mouseX, mouseY);
  
  fill(100, 0, 0)
  if (keyIsPressed === true) {
      if (key === 's') {
        text((`x: ${mouseX} y: ${mouseY}`) ,sqrt(mouseX, mouseY), 100, 100);
      }
    
        fill(0, 0, 100)
  if (keyIsPressed === true) {
      if (key === 'p') {
        text((`px: ${pmouseX} y: ${pmouseY}`) ,abs(pmouseX, pmouseY), 150, 150);
}
}
      }
}